<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "absensi_karyawan";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Buat database dan tabel jika belum ada
$sql_create_db = "CREATE DATABASE IF NOT EXISTS absensi_karyawan";
$conn->query($sql_create_db);

$conn->select_db($dbname);

$sql_create_table = "
CREATE TABLE IF NOT EXISTS absensi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    karyawan_id INT NOT NULL,
    tanggal DATE NOT NULL,
    waktu_masuk TIME,
    waktu_keluar TIME
)";
$conn->query($sql_create_table);

// Fungsi untuk menyimpan data absensi
function simpanAbsensi($conn, $karyawan_id, $tanggal, $waktu_masuk, $waktu_keluar) {
    $sql = "INSERT INTO absensi (karyawan_id, tanggal, waktu_masuk, waktu_keluar)
            VALUES ('$karyawan_id', '$tanggal', '$waktu_masuk', '$waktu_keluar')";
    if ($conn->query($sql) === TRUE) {
        echo "Data absensi berhasil disimpan<br>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
    }
}

// Fungsi untuk menampilkan data absensi
function tampilkanAbsensi($conn) {
    $sql = "SELECT * FROM absensi";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "ID: " . $row["id"]. " - Karyawan ID: " . $row["karyawan_id"]. " - Tanggal: " . $row["tanggal"]. " - Waktu Masuk: " . $row["waktu_masuk"]. " - Waktu Keluar: " . $row["waktu_keluar"]. "<br>";
        }
    } else {
        echo "0 results<br>";
    }
}

// Contoh menyimpan data absensi
$karyawan_id = 1;
$tanggal = date("Y-m-d");
$waktu_masuk = date("H:i:s");
$waktu_keluar = NULL; // misalnya waktu_keluar belum diisi
simpanAbsensi($conn, $karyawan_id, $tanggal, $waktu_masuk, $waktu_keluar);

// Tampilkan data absensi
tampilkanAbsensi($conn);

$conn->close();
?>