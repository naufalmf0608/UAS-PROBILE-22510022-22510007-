<?php

error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
include_once("config.php");

if($_SERVER['REQUEST_METHOD'] == 'GET'){
    if(isset($_GET['id_absensi'])){
        $id_absensi = $_GET['id_absensi'];
        // Query
        $queryAbsensi = mysqli_query($conn, "SELECT * FROM absensi WHERE id_absensi = '$id_absensi'");
        $rowAbsensi = $queryAbsensi->fetch_array(MYSQLI_ASSOC);

        if($rowAbsensi != null){
            echo json_encode(array("code" => 200, "status" => "success", "details" => $rowAbsensi));
        } else {
            echo json_encode(array("code" => 400, "satus" => "failed", "details" => "No Data"));
        }
    } else {
        $queryAbsensi = mysqli_query($conn, "SELECT * FROM absensi");

        while($rowAbsensi = $queryAbsensi->fetch_array(MYSQLI_ASSOC)){
            $arrayAbsensi[] = $rowAbsensi;
        }

        if($arrayAbsensi != null){
            echo json_encode(array("code" => 200, "status" => "success", "details" => $arrayAbsensi));
        } else {
            echo json_encode(array("code" => 400, "satus" => "failed", "details" => "No Data"));
        }
    }
} else if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $_POST = json_decode(file_get_contents('php://input'), true);
    $nama_mhs = $_POST['nama'];
    $nim = $_POST['nim'];
    $tanggal = $_POST['tanggal'];
    

    $queryAbsensi = mysqli_query($conn, "INSERT INTO absensi(nama, nim, tanggal) VALUES('$nama_mhs', '$nim', '$tanggal')");

    if($queryAbsensi){
        echo json_encode(array("code" => 200, "status" => "success", "details" => "Berhasil menambah data"));
    } else {
        echo json_encode(array("code" => 400, "status" => "success", "details" => "Gagal menambah data"));
    }
} else if($_SERVER['REQUEST_METHOD'] == 'PUT'){
    $_POST = json_decode(file_get_contents('php://input'), true);
    $id_absensi = $_GET['id'];
    $nama_mhs = $_POST['nama'];
    $nim = $_POST['nim'];
    $tanggal = $_POST['tanggal'];
    

    $queryAbsensi = mysqli_query($conn, "UPDATE absensi SET nama = '$nama_mhs', nim = '$nim', tanggal = '$tanggal' WHERE id_absensi = '$id_absensi'");

    if($queryAbsensi){
        echo json_encode(array("code" => 200, "status" => "success", "details" => "Berhasil mengubah data"));
    } else {
        echo json_encode(array("code" => 400, "status" => "success", "details" => "Gagal mengubah data"));
    }
} else if($_SERVER['REQUEST_METHOD'] == 'DELETE'){
    $id_absensi = $_GET['id'];
    $queryAbsensi = mysqli_query($conn, "DELETE FROM absensi WHERE id_absensi = '$id_absensi'");

    if($queryAbsensi){
        echo json_encode(array("code" => 200, "status" => "success", "details" => "Berhasil menghapus data"));
    } else {
        echo json_encode(array("code" => 400, "status" => "success", "details" => "Gagal menghapus data"));
    }
}