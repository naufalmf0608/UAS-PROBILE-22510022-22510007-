package com.example.absensi.adapter

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.absensi.FormAbsensiActivity
import com.example.absensi.PreferenceManager
import com.example.absensi.R
import com.example.absensi.model.AbsensiModel
import org.json.JSONObject
import kotlin.math.abs

class AbsensiAdapter : ListAdapter<AbsensiModel, AbsensiAdapter.ViewHolder>(DiffCallback()) {

    class DiffCallback: DiffUtil.ItemCallback<AbsensiModel>()
    {
        override fun areItemsTheSame(oldItem: AbsensiModel, newItem: AbsensiModel): Boolean {
            return oldItem.id_absensi == newItem.id_absensi
        }

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: AbsensiModel, newItem: AbsensiModel): Boolean {
            return oldItem == newItem
        }

    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
    {
        val namaNimTv = itemView.findViewById<TextView>(R.id.absensi_card_nama_nim)
        val tglTv = itemView.findViewById<TextView>(R.id.absensi_card_tanggal_jam)
        val deleteBtn = itemView.findViewById<ImageView>(R.id.absensi_card_delete)
        val item = itemView.findViewById<CardView>(R.id.absensi_card_item)
        val loading = ProgressDialog(itemView.context)

        fun bindData(absensi: AbsensiModel)
        {
            namaNimTv.text = absensi.nama + "(" + absensi.nim + ")"
            tglTv.text = absensi.tanggal
            loading.setTitle("Processing")
            loading.setTitle("Harap tunggu....")
            loading.setCancelable(false)

            item.setOnClickListener {
                val intentToForm = Intent(itemView.context, FormAbsensiActivity::class.java)
                intentToForm.putExtra("id_absensi", absensi.id_absensi)
                intentToForm.putExtra("nama", absensi.nama)
                intentToForm.putExtra("nim", absensi.nim)
                intentToForm.putExtra("tanggal", absensi.tanggal)
                itemView.context.startActivity(intentToForm)
            }

            deleteBtn.setOnClickListener {
                val dialog = AlertDialog.Builder(itemView.context)
                dialog.setTitle("Hapus data?")
                dialog.setPositiveButton("TIDAK", {dialog, wich ->
                    dialog.dismiss()
                })
                dialog.setNegativeButton("YA", {dialog, wich ->
                    deleteAbsen(loading, absensi.id_absensi)
                })
                dialog.show()
            }
        }

        private fun deleteAbsen(loading: ProgressDialog, id_absensi: Int)
        {
            loading.show()
            val url = PreferenceManager.URL + "absensi.php?id=" + id_absensi
            val stringRequest = StringRequest(
                Request.Method.DELETE, url,
                {
                    response ->
                    val responseObject = JSONObject(response)
                    if(responseObject.getInt("code") == 200){
                        Toast.makeText(itemView.context, responseObject.getString("details"), Toast.LENGTH_SHORT).show()
                        loading.dismiss()
                    } else {
                        Toast.makeText(itemView.context, responseObject.getString("details"), Toast.LENGTH_SHORT).show()
                        loading.dismiss()
                    }
                },
                {
                    error ->
                    loading.dismiss()
                })
            val queue = Volley.newRequestQueue(itemView.context)
            queue.add(stringRequest)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.absensi_card, parent, false)
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val absensi = getItem(position)
        holder.bindData(absensi)
    }
}