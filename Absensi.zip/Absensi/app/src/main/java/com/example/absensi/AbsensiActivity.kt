package com.example.absensi

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.absensi.adapter.AbsensiAdapter
import com.example.absensi.model.AbsensiModel
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.json.JSONObject
import kotlin.math.abs

class AbsensiActivity : AppCompatActivity() {

    lateinit var loading: ProgressBar
    lateinit var recyclerView: RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_absensi)

        loading = findViewById<ProgressBar>(R.id.absensi_loading)
        recyclerView = findViewById<RecyclerView>(R.id.absensi_recycler)
        val fab = findViewById<FloatingActionButton>(R.id.absensi_fab)

        getAbsensi(recyclerView, loading)

        fab.setOnClickListener {
            startActivity(Intent(this, FormAbsensiActivity::class.java))
        }
    }

    private fun getAbsensi(recyclerView: RecyclerView, loading: ProgressBar)
    {
        val url = PreferenceManager.URL + "absensi.php"
        val stringRequest = StringRequest(Request.Method.GET, url,
            {
                response ->
                val absensiList = arrayListOf<AbsensiModel>()
                val responseObject = JSONObject(response)
                if(responseObject.getInt("code") == 200){
                    val detailArray = responseObject.getJSONArray("details")
                    for(index in 0 until detailArray.length()){
                        val detailOject = detailArray.getJSONObject(index)
                        val absensi = AbsensiModel(
                            Integer.valueOf(detailOject.getString("id_absensi")),
                            detailOject.getString("nama"),
                            detailOject.getString("nim"),
                            detailOject.getString("tanggal")
                        )
                        absensiList.add(absensi)
                    }
                    val absensiAdapter = AbsensiAdapter()
                    recyclerView.adapter = absensiAdapter
                    absensiAdapter.submitList(absensiList)
                    absensiAdapter.notifyDataSetChanged()
                    loading.visibility = View.GONE
                } else {
                    Toast.makeText(this, "Tidak ada data", Toast.LENGTH_SHORT).show()
                    loading.visibility = View.GONE
                }
            },
            {
                error ->
                loading.visibility = View.GONE
            })
        val queue = Volley.newRequestQueue(this)
        queue.add(stringRequest)
    }

    override fun onResume() {
        super.onResume()
        getAbsensi(recyclerView, loading)
    }
}