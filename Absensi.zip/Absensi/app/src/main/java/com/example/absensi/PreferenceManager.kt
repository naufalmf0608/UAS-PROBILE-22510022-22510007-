package com.example.absensi

class PreferenceManager {
    companion object {
        const val URL = "http://192.168.175.18/AbsensiHarian/"
    }
}