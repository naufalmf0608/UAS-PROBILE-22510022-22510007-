package com.example.absensi.model

class AbsensiModel (
    val id_absensi: Int,
    val nama: String,
    val nim: String,
    val tanggal: String
)