package com.example.absensi

import android.app.ProgressDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.set
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class FormAbsensiActivity : AppCompatActivity() {

    var id_absensi : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_form_absensi)

        id_absensi = intent.getIntExtra("id_absensi", 0)
        val nama = intent.getStringExtra("nama")
        val nim = intent.getStringExtra("nim")
        val tanggal = intent.getStringExtra("tanggal")

        val etNama = findViewById<EditText>(R.id.etNama)
        val etNim = findViewById<EditText>(R.id.etNim)
        val etTanggal = findViewById<EditText>(R.id.etTanggal)
        val saveBtn = findViewById<Button>(R.id.absensi_save_btn)
        val loading = ProgressDialog(this)
        loading.setTitle("Processing")
        loading.setMessage("Harap tunggu...")
        loading.setCancelable(false)

        if(id_absensi != 0){
            etNama.setText(nama)
            etNim.setText(nim)
            etTanggal.setText(tanggal)
        }

        saveBtn.setOnClickListener {
            if(id_absensi == 0){
                createAbsen(etNama, etNim, etTanggal, loading)
            } else {
                updateAbsen(etNama, etNim, etTanggal, loading)
            }
        }
    }

    private fun updateAbsen(etNama: EditText?, etNim: EditText?, etTanggal: EditText?, loading: ProgressDialog)
    {
        loading.show()
        val url = PreferenceManager.URL + "absensi.php?id=" + id_absensi
        val absenObject = JSONObject()
        absenObject.put("nama", etNama?.text)
        absenObject.put("nim", etNim?.text)
        absenObject.put("tanggal", etTanggal?.text)

        val jsonRequest = object : JsonObjectRequest(Request.Method.PUT, url, absenObject,
            {
                    response ->
                if(response.getInt("code") == 200){
                    Toast.makeText(this, response.getString("details"), Toast.LENGTH_SHORT).show()
                    loading.dismiss()
                    finish()
                } else {
                    Toast.makeText(this, response.getString("details"), Toast.LENGTH_SHORT).show()
                    loading.dismiss()
                }
            },
            {
                    error ->
                Toast.makeText(this, error.message.toString(), Toast.LENGTH_SHORT).show()
                loading.dismiss()
            }){
            override fun getBodyContentType(): String {
                return "application/json"
            }
        }
        val queue = Volley.newRequestQueue(this)
        queue.add(jsonRequest)
    }

    private fun createAbsen(etNama: EditText, etNim: EditText, etTanggal: EditText, loading: ProgressDialog)
    {
        loading.show()
        val url = PreferenceManager.URL + "absensi.php"
        val absenObject = JSONObject()
        absenObject.put("nama", etNama.text)
        absenObject.put("nim", etNim.text)
        absenObject.put("tanggal", etTanggal.text)

        val jsonRequest = object : JsonObjectRequest(Request.Method.POST, url, absenObject,
            {
                response ->
                if(response.getInt("code") == 200){
                    Toast.makeText(this, response.getString("details"), Toast.LENGTH_SHORT).show()
                    loading.dismiss()
                    finish()
                } else {
                    Toast.makeText(this, response.getString("details"), Toast.LENGTH_SHORT).show()
                    loading.dismiss()
                }
            },
            {
                error ->
                Toast.makeText(this, error.message.toString(), Toast.LENGTH_SHORT).show()
                loading.dismiss()
            }){
            override fun getBodyContentType(): String {
                return "application/json"
            }
        }
        val queue = Volley.newRequestQueue(this)
        queue.add(jsonRequest)
    }
}